from private import Button, events
import requests

# ================= Helper Menu =================
async def get_panel_msg():
    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🐾 PREMIUM PANEL MENU 🐾**
━━━━━━━━━━━━━━━━━━━━━━━
🔰 **Hostname/IP:** `{DOMAIN}`
🔰 **ISP:** `{z.get("isp","Unknown")}`
🔰 **Country:** `{z.get("country","Unknown")}`
🤖 **@frel01**
━━━━━━━━━━━━━━━━━━━━━━━
"""
    return msg

# ================= Main Settings Menu =================
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("REGIS IP","regip"), Button.inline("RENEW IP","renip")],
        [Button.inline("DELETE IP","delip"), Button.inline("LIST IP","listip")],
        [Button.inline("BACKUP","backup"), Button.inline("RESTORE","restore")],
        [Button.inline("POINTING DOMAIN","point")],
        [Button.inline("REBOOT SERVER","reboot"), Button.inline("RESTART SERVICE","resx")],
        [Button.inline("SPEEDTEST","speedtest")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)

# ================= IP Menu =================
@bot.on(events.CallbackQuery(data=b'reg'))
async def reg(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("REGIS IP","regip"), Button.inline("RENEW IP","renip")],
        [Button.inline("DELETE IP","delip"), Button.inline("LIST IP","listip")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)

# ================= Backup Menu =================
@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("BACKUP","backup"), Button.inline("RESTORE","restore")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)

# ================= Pointing Domain Menu =================
@bot.on(events.CallbackQuery(data=b'pointing'))
async def pointing(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("POINTING DOMAIN","point")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)

# ================= Server Management Menu =================
@bot.on(events.CallbackQuery(data=b'server'))
async def server(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("REBOOT SERVER","reboot"), Button.inline("RESTART SERVICE","resx")],
        [Button.inline("SPEEDTEST","speedtest")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)

# ================= Main Menu =================
@bot.on(events.CallbackQuery(data=b'menu'))
async def main_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline("IP Management","reg")],
        [Button.inline("Backup & Restore","backer")],
        [Button.inline("Pointing Domain","pointing")],
        [Button.inline("Server Management","server")]
    ]
    msg = await get_panel_msg()
    await event.edit(msg, buttons=inline)
