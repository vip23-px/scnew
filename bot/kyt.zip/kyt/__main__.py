import os
from dotenv import load_dotenv

# Load variable dari var.txt
load_dotenv("/usr/bin/kyt/var.txt")

# Import semua modul
from kyt import *
from importlib import import_module
from kyt.modules import ALL_MODULES

# Muat semua file modul
for module_name in ALL_MODULES:
    import_module("kyt.modules." + module_name)

# Jalankan bot
bot.run_until_disconnected()
