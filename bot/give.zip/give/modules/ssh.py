from give import *

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    sender = await event.get_sender()
    chat = event.chat_id

    # Validasi akses
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak", alert=True)

    # Tanya durasi
    async with bot.conversation(chat) as conv:
        await event.respond("**Masukkan durasi trial (menit):**")
        resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        exp = resp.raw_text.strip()

    # Jalankan perintah pembuatan akun trial
    cmd = f'printf "%s\n" "{exp}" | bot-trial-ssh'
    try:
        output = subprocess.check_output(cmd, shell=True, text=True)
        # Parsing username & password dari output
        user = "trialuser"  # Ganti parsing sesuai output bot-trial-ssh
        pw = "trialpass"
    except subprocess.CalledProcessError as e:
        return await event.respond(f"**Gagal membuat akun trial**\n`{e}`")

    today = DT.date.today()
    later = today + DT.timedelta(days=int(exp))

    msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user}`
**» Password         :** `{pw}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» SSH WS           :** `{DOMAIN}:80@{user}:{pw}`
**» SSH SSL          :** `{DOMAIN}:443@{user}:{pw}`
**» SSH UDP          :** `{DOMAIN}:1-65535@{user}:{pw}`
**━━━━━━━━━━━━━━━━━**
**» Payload WS       :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL      :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP      :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP      :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user}.txt`
**» Expired Until:** {later}
**» 🤖 @frel01**
"""
    await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

# Menu SSH
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        return await event.answer("Access Denied", alert=True)

    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    inline = [
        [Button.inline(" CREATE TRIAL ", b"trial-ssh")],
        [Button.inline("‹ Main Menu ›", b"menu")]
    ]

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🔥 SSH OVPN MANAGER 🔥**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Service:** `SSH OVPN`
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **» @frel01**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)
