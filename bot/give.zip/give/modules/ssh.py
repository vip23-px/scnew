from give import *
import requests
from telethon import events, Button

# Mendapatkan informasi lokasi dan ISP menggunakan API
z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_(event):
        # Tombol inline untuk opsi durasi
        inline = [
            [Button.inline(" 𝟯 𝗗𝗮𝘆𝘀 ", b"trial-ssh1"),
            Button.inline(" 𝟱 𝗗𝗮𝘆𝘀 ", b"trial-ssh2")],
            [Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›", b"menu")]
        ]

        # Pesan yang akan ditampilkan
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸SSH & OVPN MENU🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🌀@freenet_on
"""
        # Edit pesan dengan tombol
        await event.edit(msg, buttons=inline)

    # Mendapatkan informasi pengirim
    sender = await event.get_sender()

    # Memeriksa validitas pengguna
    a = valid(str(sender.id))
    if a == "true":
        await ssh_(event)
    else:
        # Menampilkan pesan peringatan jika pengguna tidak valid
        await event.answer("Buy Premium Chat: @freenet_on", alert=True)
